package edu.cmu.experiments.apis;

/**
 * Created by oscarr on 8/10/18.
 */
public interface NewsService {

    String getNewsFeed(String topic);
}
